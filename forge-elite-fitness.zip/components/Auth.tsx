
import React, { useState } from 'react';
import { 
  Flame, 
  Mail, 
  Lock, 
  User as UserIcon, 
  ArrowRight, 
  Loader2, 
  Sparkles, 
  Phone, 
  Key, 
  ShieldCheck,
  Eye,
  EyeOff
} from 'lucide-react';
import { User } from '../types';

interface AuthProps {
  onLogin: (user: User) => void;
}

type AuthMode = 'login' | 'signup' | 'requestCode' | 'verifyCode';

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sentCode, setSentCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    level: 'Intermediate',
    otp: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Simulate high-performance network delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      const users: User[] = JSON.parse(localStorage.getItem('forge_users') || '[]');

      if (mode === 'login') {
        // Authenticate via Email OR Phone + Password
        const user = users.find(u => 
          (u.email.toLowerCase() === formData.email.toLowerCase() || u.phone === formData.phone) && 
          u.password === formData.password
        );
        
        if (user) {
          const { password, ...safeUser } = user;
          onLogin(safeUser as User);
        } else {
          setError('Incorrect credentials. Please verify your identity.');
        }
      } else if (mode === 'signup') {
        if (users.some(u => u.email.toLowerCase() === formData.email.toLowerCase())) {
          setError('This email is already registered.');
        } else if (users.some(u => u.phone === formData.phone)) {
          setError('This phone number is already registered.');
        } else if (!formData.phone || formData.phone.length < 8) {
          setError('Please enter a valid phone number.');
        } else if (formData.password.length < 6) {
          setError('Password must be at least 6 characters.');
        } else {
          const newUser: User = {
            id: Math.random().toString(36).substring(2, 9),
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            password: formData.password,
            level: formData.level
          };
          localStorage.setItem('forge_users', JSON.stringify([...users, newUser]));
          const { password, ...safeUser } = newUser;
          onLogin(safeUser as User);
        }
      } else if (mode === 'requestCode') {
        const user = users.find(u => u.email.toLowerCase() === formData.email.toLowerCase() || u.phone === formData.phone);
        if (user) {
          const code = Math.floor(100000 + Math.random() * 900000).toString();
          setSentCode(code);
          setMode('verifyCode');
          // In a production environment, this would integrate with an SMS/Email gateway
          console.log(`%c FORGE SECURITY CODE: ${code} `, 'background: #4f46e5; color: #fff; font-size: 20px;');
          alert(`SECURE ACCESS CODE: ${code}\n(Enter this to unlock your account)`);
        } else {
          setError('No account matches these details.');
        }
      } else if (mode === 'verifyCode') {
        if (formData.otp === sentCode) {
          const user = users.find(u => u.email.toLowerCase() === formData.email.toLowerCase() || u.phone === formData.phone);
          if (user) {
            const { password, ...safeUser } = user;
            onLogin(safeUser as User);
          }
        } else {
          setError('Verification code is invalid.');
        }
      }
    } catch (err) {
      setError('A secure connection could not be established.');
    } finally {
      setLoading(false);
    }
  };

  const renderHeader = () => {
    let title = "FORGE ELITE FITNESS";
    let sub = "The pinnacle of AI-driven performance.";
    
    if (mode === 'signup') {
      sub = "Join the top 1% of athletes.";
    } else if (mode === 'requestCode') {
      title = "SECURE RECOVERY";
      sub = "Recover your access credentials.";
    } else if (mode === 'verifyCode') {
      title = "VERIFICATION";
      sub = "Enter your unique security key.";
    }

    return (
      <div className="p-10 pt-12 text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <ShieldCheck size={120} />
        </div>
        <div className="bg-indigo-600 w-20 h-20 rounded-[28px] flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-indigo-200 rotate-3 transition-transform hover:rotate-0 duration-500 group cursor-pointer">
          <Flame size={40} className="text-white group-hover:scale-110 transition-transform" />
        </div>
        <h1 className="text-4xl font-black text-slate-900 tracking-tighter mb-2 uppercase">{title}</h1>
        <p className="text-slate-400 font-semibold text-sm max-w-[240px] mx-auto leading-relaxed">{sub}</p>
      </div>
    );
  };

  const isBaseAuth = mode === 'login' || mode === 'signup';

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 overflow-hidden relative">
      {/* Dynamic Background Elements */}
      <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-indigo-600/10 rounded-full blur-[160px] animate-pulse pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-violet-600/10 rounded-full blur-[160px] animate-pulse pointer-events-none" style={{ animationDelay: '2s' }} />

      <div className="w-full max-w-lg relative z-10 animate-in fade-in zoom-in-95 duration-1000">
        <div className="bg-white rounded-[60px] shadow-[0_32px_128px_-16px_rgba(0,0,0,0.5)] overflow-hidden border border-slate-100 flex flex-col">
          
          {renderHeader()}

          {/* Correct & Strong Choice Selection */}
          {isBaseAuth && (
            <div className="px-10 mb-8">
              <div className="flex p-2 bg-slate-100/80 rounded-[32px] gap-2 border border-slate-200/50 backdrop-blur-sm">
                <button
                  type="button"
                  onClick={() => { setMode('login'); setError(''); }}
                  className={`flex-1 py-4 rounded-[24px] text-sm font-black transition-all duration-300 ${mode === 'login' ? 'bg-white text-indigo-600 shadow-xl shadow-slate-200/50 scale-[1.02]' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  LOG IN
                </button>
                <button
                  type="button"
                  onClick={() => { setMode('signup'); setError(''); }}
                  className={`flex-1 py-4 rounded-[24px] text-sm font-black transition-all duration-300 ${mode === 'signup' ? 'bg-white text-indigo-600 shadow-xl shadow-slate-200/50 scale-[1.02]' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  SIGN UP
                </button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="px-10 pb-12 space-y-5">
            {mode === 'signup' && (
              <div className="space-y-1 animate-in slide-in-from-left-4 duration-300">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Full Name</label>
                <div className="relative group">
                  <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                  <input 
                    required
                    type="text" 
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter full name"
                    className="w-full pl-14 pr-6 py-4.5 bg-slate-50 border-2 border-transparent rounded-[24px] font-bold text-slate-800 placeholder:text-slate-300 focus:bg-white focus:border-indigo-600/20 focus:ring-4 focus:ring-indigo-600/5 transition-all outline-none"
                  />
                </div>
              </div>
            )}

            {(mode === 'login' || mode === 'signup' || mode === 'requestCode') && (
              <div className="space-y-1 animate-in slide-in-from-left-4 duration-400">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Identity (Phone or Email)</label>
                <div className="space-y-3">
                  <div className="relative group">
                    <Phone className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      required={!formData.email}
                      type="tel" 
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                      placeholder="+1 Phone Number"
                      className="w-full pl-14 pr-6 py-4.5 bg-slate-50 border-2 border-transparent rounded-[24px] font-bold text-slate-800 placeholder:text-slate-300 focus:bg-white focus:border-indigo-600/20 focus:ring-4 focus:ring-indigo-600/5 transition-all outline-none"
                    />
                  </div>
                  <div className="relative group">
                    <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      required={!formData.phone || mode === 'signup'}
                      readOnly={mode === 'verifyCode'}
                      type="email" 
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      placeholder="Email Address"
                      className={`w-full pl-14 pr-6 py-4.5 bg-slate-50 border-2 border-transparent rounded-[24px] font-bold text-slate-800 placeholder:text-slate-300 focus:bg-white focus:border-indigo-600/20 focus:ring-4 focus:ring-indigo-600/5 transition-all outline-none ${mode === 'verifyCode' ? 'opacity-50' : ''}`}
                    />
                  </div>
                </div>
              </div>
            )}

            {(mode === 'login' || mode === 'signup') && (
              <div className="space-y-1 animate-in slide-in-from-left-4 duration-500">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Secret Key</label>
                <div className="relative group">
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                  <input 
                    required
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={e => setFormData({...formData, password: e.target.value})}
                    placeholder="Enter password"
                    className="w-full pl-14 pr-14 py-4.5 bg-slate-50 border-2 border-transparent rounded-[24px] font-bold text-slate-800 placeholder:text-slate-300 focus:bg-white focus:border-indigo-600/20 focus:ring-4 focus:ring-indigo-600/5 transition-all outline-none"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 transition-colors"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </div>
              </div>
            )}

            {mode === 'verifyCode' && (
              <div className="space-y-1 animate-in zoom-in-95 duration-500">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 text-center block">Enter 6-Digit Security Code</label>
                <div className="relative group">
                  <Key className="absolute left-6 top-1/2 -translate-y-1/2 text-indigo-500" size={24} />
                  <input 
                    required
                    type="text" 
                    maxLength={6}
                    value={formData.otp}
                    onChange={e => setFormData({...formData, otp: e.target.value})}
                    placeholder="••••••"
                    className="w-full pl-16 pr-6 py-6 bg-slate-50 border-2 border-indigo-100 rounded-[32px] font-black text-3xl tracking-[0.6em] text-center text-indigo-600 focus:ring-8 focus:ring-indigo-600/5 transition-all outline-none shadow-inner"
                  />
                </div>
              </div>
            )}

            {mode === 'signup' && (
              <div className="space-y-1 animate-in slide-in-from-left-4 duration-600">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Starting Proficiency</label>
                <div className="grid grid-cols-3 gap-2">
                  {['Beginner', 'Intermediate', 'Pro'].map(l => (
                    <button
                      key={l}
                      type="button"
                      onClick={() => setFormData({...formData, level: l})}
                      className={`py-3.5 rounded-[20px] text-[10px] font-black transition-all border-2 ${formData.level === l ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-lg shadow-indigo-100/50' : 'border-slate-50 bg-slate-50 text-slate-400 hover:border-slate-200'}`}
                    >
                      {l.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-50 text-red-600 text-xs font-bold rounded-2xl text-center animate-in shake duration-300 flex items-center justify-center gap-2">
                <ShieldCheck size={14} />
                {error}
              </div>
            )}

            <button
              disabled={loading}
              className="w-full py-5.5 bg-indigo-600 text-white rounded-[32px] font-black text-xl flex items-center justify-center gap-4 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-2xl shadow-indigo-200 active:scale-[0.98] mt-4 group"
            >
              {loading ? (
                <>
                  <Loader2 className="animate-spin" size={24} />
                  VERIFYING...
                </>
              ) : (
                <>
                  {mode === 'login' && 'UNLEASH PEAK POWER'}
                  {mode === 'signup' && 'BEGIN EVOLUTION'}
                  {mode === 'requestCode' && 'SEND ACCESS KEY'}
                  {mode === 'verifyCode' && 'VERIFY IDENTITY'}
                  <ArrowRight size={24} className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
            
            {mode === 'login' && (
              <div className="text-center pt-3">
                <button 
                  type="button"
                  onClick={() => { setMode('requestCode'); setError(''); }}
                  className="text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors flex items-center justify-center gap-2 mx-auto"
                >
                  <Key size={14} />
                  Unable to access? Get a security code
                </button>
              </div>
            )}

            {(mode === 'requestCode' || mode === 'verifyCode') && (
              <div className="text-center pt-3">
                <button 
                  type="button"
                  onClick={() => { setMode('login'); setError(''); }}
                  className="text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors flex items-center justify-center gap-2 mx-auto"
                >
                  Return to Standard Login
                </button>
              </div>
            )}
          </form>

          <div className="p-10 bg-slate-50/50 text-center border-t border-slate-100 mt-auto">
            <div className="flex items-center justify-center gap-2 text-slate-400 font-bold text-xs uppercase tracking-[0.2em]">
              <Sparkles size={16} className="text-indigo-400 animate-pulse" />
              Elite Encryption Enabled
            </div>
          </div>
        </div>
        
        <div className="mt-10 flex flex-col items-center gap-4">
          <div className="flex items-center gap-3 text-slate-500">
            <div className="h-px w-8 bg-slate-800" />
            <ShieldCheck size={20} className="text-indigo-500" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em]">Authorized Access Only</span>
            <div className="h-px w-8 bg-slate-800" />
          </div>
          <p className="text-[10px] text-slate-600 font-medium text-center opacity-60 max-w-[280px]">
            Protected by Forge Elite Security Systems. Unauthorized attempts are monitored.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;