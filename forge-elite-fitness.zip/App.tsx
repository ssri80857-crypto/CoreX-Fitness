
import React, { useState, useEffect } from 'react';
import { View, Workout, ProgressData, User as UserType } from './types';
import Dashboard from './components/Dashboard';
import WorkoutLibrary from './components/WorkoutLibrary';
import AIPlanner from './components/AIPlanner';
import AICoach from './components/AICoach';
import ProgressCharts from './components/ProgressCharts';
import WaterTracker from './components/WaterTracker';
import BodyPartExercises from './components/BodyPartExercises';
import DietPlanner from './components/DietPlanner';
import PlanMaker from './components/PlanMaker';
import BurnCalculator from './components/BurnCalculator';
import Store from './components/Store';
import Auth from './components/Auth';
import Feed from './components/Feed';
import AIAssistant from './components/AIAssistant';
import { 
  LayoutDashboard, 
  Dumbbell, 
  BrainCircuit, 
  MessageSquare, 
  LineChart, 
  Flame,
  User,
  Droplets,
  BookOpen,
  Apple,
  CalendarDays,
  Flame as FireIcon,
  ShoppingBag,
  LogOut,
  Users,
  ShieldAlert,
  LucideIcon
} from 'lucide-react';

const INITIAL_PROGRESS: ProgressData[] = [
  { day: 'Mon', calories: 0, duration: 0 },
  { day: 'Tue', calories: 0, duration: 0 },
  { day: 'Wed', calories: 0, duration: 0 },
  { day: 'Thu', calories: 0, duration: 0 },
  { day: 'Fri', calories: 0, duration: 0 },
  { day: 'Sat', calories: 0, duration: 0 },
  { day: 'Sun', calories: 0, duration: 0 },
];

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [progress, setProgress] = useState<ProgressData[]>(INITIAL_PROGRESS);
  const [user, setUser] = useState<UserType | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('forge_current_user');
    if (savedUser) setUser(JSON.parse(savedUser));

    const savedWorkouts = localStorage.getItem('forge_workouts');
    if (savedWorkouts) setWorkouts(JSON.parse(savedWorkouts));

    const savedProgress = localStorage.getItem('forge_progress');
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress));
    } else {
      localStorage.setItem('forge_progress', JSON.stringify(INITIAL_PROGRESS));
    }
    
    setIsLoaded(true);
  }, []);

  const handleLogin = (newUser: UserType) => {
    setUser(newUser);
    localStorage.setItem('forge_current_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('forge_current_user');
  };

  const saveWorkouts = (newWorkouts: Workout[]) => {
    setWorkouts(newWorkouts);
    localStorage.setItem('forge_workouts', JSON.stringify(newWorkouts));
  };

  const updateProgress = (newProgress: ProgressData[]) => {
    setProgress(newProgress);
    localStorage.setItem('forge_progress', JSON.stringify(newProgress));
  };

  if (!isLoaded) return null;

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  const NavItem = ({ view, icon: Icon, label }: { view: View, icon: LucideIcon, label: string }) => (
    <button
      onClick={() => setCurrentView(view)}
      className={`flex flex-col items-center justify-center py-2 px-1 transition-all duration-200 ${
        currentView === view 
        ? 'text-indigo-600 scale-110' 
        : 'text-slate-400 hover:text-slate-600'
      }`}
    >
      <Icon size={18} strokeWidth={currentView === view ? 2.5 : 2} />
      <span className="text-[8px] font-black mt-1 uppercase tracking-tighter text-center">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Desktop Sidebar */}
      <nav className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 p-6 sticky top-0 h-screen">
        <div className="flex items-center gap-3 mb-10">
          <div className="bg-indigo-600 p-2 rounded-xl text-white">
            <Flame size={24} />
          </div>
          <h1 className="text-xl font-black tracking-tighter text-slate-800 leading-tight">FORGE<br/>ELITE<br/>FITNESS</h1>
        </div>
        
        <div className="space-y-1 flex-1 overflow-y-auto pr-2 scrollbar-hide">
          <SidebarLink active={currentView === View.DASHBOARD} onClick={() => setCurrentView(View.DASHBOARD)} icon={<LayoutDashboard size={20}/>} label="Dashboard" />
          <SidebarLink active={currentView === View.ASSISTANT} onClick={() => setCurrentView(View.ASSISTANT)} icon={<ShieldAlert size={20}/>} label="System Nexus" />
          <SidebarLink active={currentView === View.FEED} onClick={() => setCurrentView(View.FEED)} icon={<Users size={20}/>} label="Community Feed" />
          <SidebarLink active={currentView === View.STORE} onClick={() => setCurrentView(View.STORE)} icon={<ShoppingBag size={20}/>} label="Forge Store" />
          <SidebarLink active={currentView === View.CALORIES} onClick={() => setCurrentView(View.CALORIES)} icon={<FireIcon size={20}/>} label="Burn Calc" />
          <SidebarLink active={currentView === View.MAKE_PLAN} onClick={() => setCurrentView(View.MAKE_PLAN)} icon={<CalendarDays size={20}/>} label="Make a Plan" />
          <SidebarLink active={currentView === View.WATER} onClick={() => setCurrentView(View.WATER)} icon={<Droplets size={20}/>} label="Hydration" />
          <SidebarLink active={currentView === View.DIET} onClick={() => setCurrentView(View.DIET)} icon={<Apple size={20}/>} label="Diet Architect" />
          <SidebarLink active={currentView === View.WORKOUTS} onClick={() => setCurrentView(View.WORKOUTS)} icon={<Dumbbell size={20}/>} label="Workout Log" />
          <SidebarLink active={currentView === View.EXERCISES} onClick={() => setCurrentView(View.EXERCISES)} icon={<BookOpen size={20}/>} label="Exercise Guide" />
          <SidebarLink active={currentView === View.PLANNER} onClick={() => setCurrentView(View.PLANNER)} icon={<BrainCircuit size={20}/>} label="AI Planner" />
          <SidebarLink active={currentView === View.COACH} onClick={() => setCurrentView(View.COACH)} icon={<MessageSquare size={20}/>} label="Forge Coach" />
          <SidebarLink active={currentView === View.PROGRESS} onClick={() => setCurrentView(View.PROGRESS)} icon={<LineChart size={20}/>} label="Progress" />
        </div>

        <div className="mt-auto pt-4 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700">
              <User size={20} />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-700 truncate w-24">{user.name}</p>
              <p className="text-xs text-slate-500">{user.level}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
            title="Sign Out"
          >
            <LogOut size={18} />
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-24 md:pb-0">
        <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 py-4 flex justify-between items-center md:hidden">
          <div className="flex items-center gap-2">
             <Flame className="text-indigo-600" size={24} />
             <h1 className="font-black text-lg tracking-tighter">FORGE ELITE FITNESS</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center">
              <User size={18} />
            </div>
            <button onClick={handleLogout} className="text-slate-400">
              <LogOut size={18} />
            </button>
          </div>
        </header>

        <div className="max-w-5xl mx-auto p-4 md:p-8">
          {currentView === View.DASHBOARD && <Dashboard workouts={workouts} progress={progress} onUpdateProgress={updateProgress} />}
          {currentView === View.ASSISTANT && <AIAssistant />}
          {currentView === View.FEED && <Feed user={user} />}
          {currentView === View.STORE && <Store />}
          {currentView === View.CALORIES && <BurnCalculator progress={progress} onUpdateProgress={updateProgress} />}
          {currentView === View.MAKE_PLAN && <PlanMaker onPlanAccepted={(newWorkouts) => saveWorkouts([...workouts, ...newWorkouts])} />}
          {currentView === View.WATER && <WaterTracker />}
          {currentView === View.DIET && <DietPlanner />}
          {currentView === View.WORKOUTS && <WorkoutLibrary workouts={workouts} onUpdate={saveWorkouts} />}
          {currentView === View.EXERCISES && <BodyPartExercises />}
          {currentView === View.PLANNER && <AIPlanner onPlanGenerated={(newWorkouts) => saveWorkouts([...workouts, ...newWorkouts])} />}
          {currentView === View.COACH && <AICoach />}
          {currentView === View.PROGRESS && <ProgressCharts progress={progress} />}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around items-center z-20 h-20 px-1 shadow-[0_-4px_10px_rgba(0,0,0,0.05)] overflow-x-auto whitespace-nowrap scrollbar-hide">
        <NavItem view={View.DASHBOARD} icon={LayoutDashboard} label="Home" />
        <NavItem view={View.ASSISTANT} icon={ShieldAlert} label="Nexus" />
        <NavItem view={View.FEED} icon={Users} label="Feed" />
        <NavItem view={View.STORE} icon={ShoppingBag} label="Store" />
        <NavItem view={View.CALORIES} icon={FireIcon} label="Burn" />
        <NavItem view={View.MAKE_PLAN} icon={CalendarDays} label="Plan" />
        <NavItem view={View.WATER} icon={Droplets} label="Water" />
        <NavItem view={View.DIET} icon={Apple} label="Diet" />
        <NavItem view={View.WORKOUTS} icon={Dumbbell} label="Logs" />
        <NavItem view={View.EXERCISES} icon={BookOpen} label="Guide" />
        <NavItem view={View.COACH} icon={MessageSquare} label="Coach" />
      </nav>
    </div>
  );
};

interface SidebarLinkProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

const SidebarLink = ({ active, onClick, icon, label }: SidebarLinkProps) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
      active 
      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' 
      : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'
    }`}
  >
    {icon}
    {label}
  </button>
);

export default App;
